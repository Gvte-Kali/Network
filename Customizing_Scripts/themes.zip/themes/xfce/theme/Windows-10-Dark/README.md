[![built-with-azurra-framework](https://github.com/B00merang-Project/B00merang-Project.github.io/blob/master/resources/badges/azurra/badge_smaller.png)](https://github.com/B00merang-Project/Azurra_framework)

# Windows 10 Dark
GTK theme based on the appearance of Windows 10 using the included dark mode.

### Preview
![Windows-10-Dark](https://github.com/B00merang-Project/gallery/raw/master/Windows%2010%20Dark%20(3).png)

### Supported platforms
- Any GTK-based desktop
- Cinnamon
- Gnome
- LXDE/Openbox
- MATE
- Xfce

### Manual installation
Go to releases, download the latest `.zip` file and extract it to the themes directory i.e. `/home/USERNAME/.themes`
